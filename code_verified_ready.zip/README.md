# OKComputerAI 2.0

نظام إدارة تواصل ذكي متعدد القنوات مع مساعد ذكي يتعلم ويتذكر.

## المميزات الرئيسية

- **إدارة متعددة القنوات**: فيسبوك، واتساب، جوجل شيتس، Shopify
- **مساعد ذكي بذاكرة**: يتعلم من الأوامر والتعديلات
- **نظام حسابات متقدم**: حساب العمولات وتحليل الأداء
- **لوحة تحكم شاملة**: إدارة المناديب والطلبات والتقارير
- **صلاحيات تحرير ديناميكية**: تعديل أي شيء بأوامر طبيعية
- **معالجة متوازية**: سرعة عالية في معالجة الرسائل
- **نظام الذاكرة الذكية**: يتذكر التفضيلات والسلوكيات

## التثبيت

### المتطلبات
- Python 3.11+
- Git

### خطوات التثبيت المحلية

\`\`\`bash
# استنساخ المشروع
git clone https://github.com/yourusername/OKComputerAI2.git
cd OKComputerAI2

# إنشاء بيئة افتراضية
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# تثبيت المتطلبات
pip install -r requirements.txt

# إنشاء ملف .env
cp .env.example .env

# تعديل .env بإضافة مفاتيحك الخاصة
nano .env  # أو استخدم محرر نصوص آخر

# تشغيل التطبيق
python run.py
\`\`\`

## النشر على Vercel

### 1. إنشاء حساب Vercel
اذهب إلى https://vercel.com وأنشئ حساباً

### 2. ربط مع GitHub
\`\`\`bash
git remote add origin https://github.com/yourusername/OKComputerAI2.git
git branch -M main
git push -u origin main
\`\`\`

### 3. نشر على Vercel
\`\`\`bash
npm install -g vercel
vercel
\`\`\`

أو استخدم لوحة التحكم:
1. اذهب إلى https://vercel.com/dashboard
2. اضغط "Import Project"
3. اختر مستودع GitHub الخاص بك
4. أضف متغيرات البيئة من خادم Vercel
5. اضغط "Deploy"

## المتغيرات البيئية المطلوبة

في Vercel Dashboard، أضف المتغيرات التالية:

\`\`\`
FLASK_ENV=production
OPENAI_API_KEY=sk-xxxxx
FACEBOOK_ACCESS_TOKEN=xxxxx
WHATSAPP_API_KEY=xxxxx
GOOGLE_SHEET_ID=xxxxx
SHOPIFY_API_KEY=xxxxx
DATABASE_URL=postgres://xxxxx
REDIS_URL=redis://xxxxx
\`\`\`

## الاستخدام

### الوصول للتطبيق
- محليًا: http://localhost:5000
- على Vercel: https://your-project.vercel.app

### تسجيل الدخول
استخدم بيانات الاعتماد الافتراضية (يجب تغييرها في الإنتاج)

### إرسال الأوامر للمساعد الذكي
\`\`\`bash
curl -X POST http://localhost:5000/api/admin/command \
  -H "Content-Type: application/json" \
  -d '{
    "command": "زيادة عمولة محمد إلى 15%",
    "admin_id": "admin_1"
  }'
\`\`\`

## البنية

\`\`\`
.
├── app.py                 # تطبيق Flask الرئيسي
├── core.py               # منطق النظام الأساسي
├── ai_memory.py          # نظام الذاكرة الذكية
├── db.py                 # إدارة قاعدة البيانات
├── requirements.txt      # المتطلبات
├── templates/            # قوالب HTML
├── static/               # الملفات الثابتة
└── README.md            # هذا الملف
\`\`\`

## المساعد الذكي

المساعد الذكي يمكنه:
- **فهم الأوامر الطبيعية**: "زيادة السعر بـ 10%" أو "عدّل عمولة أحمد"
- **التعلم من التعديلات**: يتذكر الأوامر السابقة ويحسّن من الردود
- **تنفيذ العمليات**: تطبيق التغييرات فوراً دون تأخير
- **الإرجاع الذكي**: يشرح ما فعله بوضوح

## الأمان

- تشفير كلمات المرور
- CSRF Protection
- Rate Limiting
- Two-Factor Authentication (قريباً)
- تسجيل التدقيق الكامل

## الدعم

للمساعدة والدعم:
- افتح Issue على GitHub
- راسل عبر البريد الإلكتروني

## الترخيص

MIT License - انظر LICENSE للتفاصيل

## المساهمون

تم التطوير بواسطة فريق OKComputerAI
