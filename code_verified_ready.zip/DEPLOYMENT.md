# دليل النشر الشامل

## النشر على Vercel

### المرحلة الأولى: التحضير

1. **تأكد من وجود git مثبت**
\`\`\`bash
git --version
\`\`\`

2. **أنشئ مستودع GitHub**
- اذهب إلى github.com/new
- أنشئ مستودع جديد باسم "OKComputerAI2"

3. **رفع الكود إلى GitHub**
\`\`\`bash
git init
git add .
git commit -m "Initial commit: OKComputerAI 2.0"
git branch -M main
git remote add origin https://github.com/yourusername/OKComputerAI2.git
git push -u origin main
\`\`\`

### المرحلة الثانية: إعداد Vercel

1. **اذهب إلى https://vercel.com**
2. **اضغط "Sign up" واختر GitHub**
3. **وافق على الأذونات**
4. **اضغط "Import Project"**
5. **اختر المستودع "OKComputerAI2"**
6. **في إعدادات المشروع:**
   - Build Command: `pip install -r requirements.txt`
   - Output Directory: `.`
   - Install Command: `pip install -r requirements.txt`

### المرحلة الثالثة: متغيرات البيئة

1. في Vercel Dashboard، اذهب إلى Settings
2. اختر "Environment Variables"
3. أضف كل متغير:

\`\`\`
FLASK_ENV = production
OPENAI_API_KEY = sk-your-key-here
FACEBOOK_ACCESS_TOKEN = your-token
WHATSAPP_API_KEY = your-key
GOOGLE_SHEET_ID = your-id
SHOPIFY_API_KEY = your-key
DATABASE_URL = your-database-url
REDIS_URL = your-redis-url
\`\`\`

4. اضغط "Deploy"

## النشر المحلي

### باستخدام Docker

\`\`\`dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["gunicorn", "--bind", "0.0.0.0:5000", "app:app"]
\`\`\`

\`\`\`bash
docker build -t okcomputerai2 .
docker run -p 5000:5000 okcomputerai2
\`\`\`

## التحقق من النشر

1. زيارة رابط التطبيق على Vercel
2. التحقق من:
   - صحة تسجيل الدخول
   - توصيل API
   - وظائف الواجهة

## استكشاف الأخطاء

### المشكلة: "Module not found"
**الحل**: تأكد من تثبيت جميع المتطلبات
\`\`\`bash
pip install -r requirements.txt
\`\`\`

### المشكلة: "Connection refused"
**الحل**: تحقق من متغيرات البيئة والاتصال بالقاعدة

### المشكلة: "Timeout"
**الحل**: زيادة timeout في Vercel Settings

## نصائح الأداء

1. استخدم Redis للتخزين المؤقت
2. فعّل compression في Flask
3. استخدم CDN للملفات الثابتة
4. راقب استخدام الذاكرة
