#!/bin/bash

# نظام إدارة التواصل الذكي - تثبيت Linux/Mac

echo "==============================================="
echo "    نظام إدارة التواصل الذكي - تثبيت Unix"
echo "==============================================="
echo "    نسخة مصرية متكاملة مع ذكاء اصطناعي متقدم"
echo "==============================================="

# التحقق من Python
echo "[1] التحقق من Python..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 غير مثبت. يرجى تثبيت Python 3.7 أو أحدث."
    echo "📥 https://www.python.org/downloads/"
    exit 1
fi
echo "✅ Python3 مثبت"

# التحقق من pip
echo "[2] التحقق من pip..."
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 غير مثبت. جاري التثبيت..."
    python3 -m ensurepip --upgrade
fi
echo "✅ pip3 مثبت"

# تثبيت المتطلبات
echo "[3] تثبيت المتطلبات..."
pip3 install -r requirements.txt
if [ $? -ne 0 ]; then
    echo "❌ فشل تثبيت المتطلبات"
    exit 1
fi
echo "✅ تم تثبيت المتطلبات"

# إعداد متغيرات البيئة
echo "[4] إعداد متغيرات البيئة..."
export ADMIN_PASS="admin123"
export SECRET_KEY="your-secret-key-here"
export SHOPIFY_STORE_URL="free-move-eg.myshopify.com"
echo "✅ تم إعداد متغيرات البيئة"

# تهيئة قاعدة البيانات
echo "[5] تهيئة قاعدة البيانات..."
python3 -c "import db; db.init_database()"
echo "✅ تم تهيئة قاعدة البيانات"

# جعل الملفات قابلة للتنفيذ
chmod +x run.py
chmod +x install.sh
chmod +x update.py

echo "==============================================="
echo "🎉 تم التثبيت بنجاح!"
echo "==============================================="
echo "🔑 كلمة مرور المسؤول: admin123"
echo "📱 لوحة التحكم: http://localhost:5000/admin/dashboard"
echo "📱 دخول المندوب: http://localhost:5000/agent"
echo "🤖 المساعد الذكي: متاح في جميع الصفحات"
echo "==============================================="
echo "🚀 لتشغيل النظام:"
echo "    python3 run.py"
echo "==============================================="
echo "💡 مميزات النسخة المصرية:"
echo "   • أسعار بالجنيه المصري"
echo "   • مناطق توصيل مصرية"
echo "   • طرق دفع محلية"
echo "   • لغة عاملية مصرية"
echo "   • تقارير تلقائية للواتساب"
echo "   • تكامل مع Shopify"
echo "==============================================="
