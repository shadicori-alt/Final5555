"""
نظام الذاكرة الذكية والتعلم للمساعد الاصطناعي
يسمح بتذكر الأوامر والتعديلات وتطبيقها تلقائياً
"""

import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import hashlib
from db import add_log

class AIMemorySystem:
    """نظام ذاكرة المساعد الذكي مع القدرة على التعلم والتحديث الديناميكي"""
    
    def __init__(self):
        self.memory_db = 'ai_memory.db'
        self.init_memory_database()
        self.learning_threshold = 0.8  # حد التعلم والتطبيق التلقائي
        
    def init_memory_database(self):
        """إنشاء قاعدة بيانات الذاكرة"""
        conn = sqlite3.connect(self.memory_db)
        cursor = conn.cursor()
        
        # جدول السلوكيات المتعلمة
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS learned_behaviors (
                id INTEGER PRIMARY KEY,
                behavior_id TEXT UNIQUE,
                trigger_pattern TEXT,
                response_template TEXT,
                response_format TEXT,
                confidence REAL DEFAULT 0.0,
                usage_count INTEGER DEFAULT 0,
                success_rate REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # جدول الأوامر والتعديلات
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS admin_commands (
                id INTEGER PRIMARY KEY,
                command_id TEXT UNIQUE,
                command_text TEXT,
                command_type TEXT,
                target TEXT,
                action TEXT,
                parameters TEXT,
                auto_apply BOOLEAN DEFAULT 0,
                applied_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                executed_at TIMESTAMP
            )
        ''')
        
        # جدول نماذج الرد الديناميكية
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS response_templates (
                id INTEGER PRIMARY KEY,
                template_id TEXT UNIQUE,
                category TEXT,
                template_text TEXT,
                variables TEXT,
                priority INTEGER DEFAULT 0,
                active BOOLEAN DEFAULT 1,
                used_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # جدول الحسابات والعمليات المالية
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS financial_records (
                id INTEGER PRIMARY KEY,
                record_id TEXT UNIQUE,
                transaction_type TEXT,
                amount REAL,
                currency TEXT DEFAULT 'EGP',
                description TEXT,
                agent_id TEXT,
                related_order_id TEXT,
                commission REAL DEFAULT 0,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                settled_at TIMESTAMP
            )
        ''')
        
        # جدول تصحيحات الأخطاء المتعلمة
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS error_corrections (
                id INTEGER PRIMARY KEY,
                error_pattern TEXT,
                error_type TEXT,
                correction_action TEXT,
                severity INTEGER,
                auto_fix BOOLEAN DEFAULT 0,
                applied_count INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def learn_behavior(self, trigger_pattern: str, response: str, success: bool = True):
        """تعلم سلوك جديد أو تحديث سلوك موجود"""
        conn = sqlite3.connect(self.memory_db)
        cursor = conn.cursor()
        
        behavior_id = hashlib.md5(trigger_pattern.encode()).hexdigest()
        
        cursor.execute('SELECT * FROM learned_behaviors WHERE behavior_id = ?', (behavior_id,))
        existing = cursor.fetchone()
        
        if existing:
            # تحديث السلوك الموجود
            success_rate = (existing[8] * existing[7] + (1 if success else 0)) / (existing[7] + 1)
            cursor.execute('''
                UPDATE learned_behaviors 
                SET response_template = ?, usage_count = usage_count + 1, 
                    success_rate = ?, updated_at = CURRENT_TIMESTAMP
                WHERE behavior_id = ?
            ''', (response, success_rate, behavior_id))
        else:
            # إنشاء سلوك جديد
            cursor.execute('''
                INSERT INTO learned_behaviors 
                (behavior_id, trigger_pattern, response_template, success_rate, usage_count)
                VALUES (?, ?, ?, ?, 1)
            ''', (behavior_id, trigger_pattern, response, 1.0 if success else 0.5))
        
        conn.commit()
        conn.close()
        
        add_log('info', f'Behavior learned: {trigger_pattern}', 'ai_memory')
    
    def get_learned_response(self, trigger_pattern: str) -> Optional[str]:
        """الحصول على رد متعلم من الذاكرة"""
        conn = sqlite3.connect(self.memory_db)
        cursor = conn.cursor()
        
        # البحث عن نمط متطابق أو قريب
        cursor.execute('''
            SELECT response_template, success_rate 
            FROM learned_behaviors 
            WHERE trigger_pattern LIKE ? AND success_rate > ?
            ORDER BY success_rate DESC, usage_count DESC
            LIMIT 1
        ''', (f'%{trigger_pattern}%', self.learning_threshold))
        
        result = cursor.fetchone()
        conn.close()
        
        return result[0] if result else None
    
    def add_admin_command(self, command_text: str, auto_apply: bool = False) -> str:
        """إضافة أمر من الإدارة لتطبيقه"""
        conn = sqlite3.connect(self.memory_db)
        cursor = conn.cursor()
        
        command_id = hashlib.md5(f"{command_text}{datetime.now()}".encode()).hexdigest()
        
        # تحليل الأمر
        parsed = self._parse_command(command_text)
        
        cursor.execute('''
            INSERT INTO admin_commands 
            (command_id, command_text, command_type, target, action, parameters, auto_apply)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (command_id, command_text, parsed['type'], parsed['target'], 
              parsed['action'], json.dumps(parsed['params']), auto_apply))
        
        conn.commit()
        conn.close()
        
        add_log('info', f'Admin command added: {command_text}', 'admin_commands')
        return command_id
    
    def _parse_command(self, command_text: str) -> Dict:
        """تحليل أوامر الإدارة الطبيعية"""
        command_lower = command_text.lower()
        
        # تحليل أنواع الأوامر المختلفة
        if 'غير' in command_lower or 'تعديل' in command_lower:
            return {'type': 'modify', 'target': 'response', 'action': 'update', 'params': {}}
        elif 'حذف' in command_lower:
            return {'type': 'delete', 'target': 'response', 'action': 'remove', 'params': {}}
        elif 'إضافة' in command_lower or 'أضف' in command_lower:
            return {'type': 'add', 'target': 'response', 'action': 'create', 'params': {}}
        elif 'قيمة' in command_lower or 'سعر' in command_lower:
            return {'type': 'modify', 'target': 'price', 'action': 'update', 'params': {}}
        elif 'راتب' in command_lower or 'عمولة' in command_lower:
            return {'type': 'modify', 'target': 'commission', 'action': 'update', 'params': {}}
        else:
            return {'type': 'general', 'target': 'system', 'action': 'execute', 'params': {}}
    
    def apply_pending_commands(self) -> List[str]:
        """تطبيق الأوامر المعلقة"""
        conn = sqlite3.connect(self.memory_db)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT command_id, command_text, command_type, action, parameters 
            FROM admin_commands 
            WHERE auto_apply = 1 AND executed_at IS NULL
        ''')
        
        pending_commands = cursor.fetchall()
        applied = []
        
        for cmd_id, cmd_text, cmd_type, action, params in pending_commands:
            try:
                self._execute_command(cmd_id, cmd_type, action, json.loads(params))
                applied.append(cmd_id)
                
                cursor.execute('''
                    UPDATE admin_commands 
                    SET executed_at = CURRENT_TIMESTAMP, applied_count = applied_count + 1
                    WHERE command_id = ?
                ''', (cmd_id,))
                
            except Exception as e:
                add_log('error', f'Failed to apply command: {cmd_text}', 'admin_commands', str(e))
        
        conn.commit()
        conn.close()
        
        return applied
    
    def _execute_command(self, cmd_id: str, cmd_type: str, action: str, params: Dict):
        """تنفيذ الأمر الفعلي"""
        # هذه الدالة ستُفعل حسب نوع الأمر
        add_log('info', f'Executing command {cmd_id}: {cmd_type} - {action}', 'command_execution')
    
    def add_response_template(self, category: str, template_text: str, priority: int = 0):
        """إضافة نموذج رد جديد"""
        conn = sqlite3.connect(self.memory_db)
        cursor = conn.cursor()
        
        template_id = hashlib.md5(f"{category}{template_text}".encode()).hexdigest()
        
        cursor.execute('''
            INSERT INTO response_templates 
            (template_id, category, template_text, priority, active)
            VALUES (?, ?, ?, ?, 1)
        ''', (template_id, category, template_text, priority))
        
        conn.commit()
        conn.close()
    
    def get_response_template(self, category: str) -> Optional[str]:
        """جلب نموذج رد من الذاكرة"""
        conn = sqlite3.connect(self.memory_db)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT template_text FROM response_templates 
            WHERE category = ? AND active = 1
            ORDER BY priority DESC, used_count DESC
            LIMIT 1
        ''', (category,))
        
        result = cursor.fetchone()
        conn.close()
        
        return result[0] if result else None


class FinancialCalculator:
    """نظام حساب العمليات المالية والعمولات"""
    
    def __init__(self):
        self.memory_system = AIMemorySystem()
        self.currency = 'EGP'
    
    def calculate_commission(self, order_amount: float, agent_id: str) -> Dict:
        """حساب عمولة المندوب"""
        # نسب عمولة ديناميكية حسب الأداء
        base_commission_rate = 0.05  # 5% أساسي
        
        # جلب إحصائيات المندوب
        agent_stats = self._get_agent_stats(agent_id)
        
        # تحديث معدل العمولة حسب الأداء
        if agent_stats['success_rate'] > 0.95:
            commission_rate = 0.08  # 8% للمتميزين
        elif agent_stats['success_rate'] > 0.85:
            commission_rate = 0.07  # 7%
        else:
            commission_rate = base_commission_rate
        
        commission = order_amount * commission_rate
        
        return {
            'order_amount': order_amount,
            'commission_rate': commission_rate,
            'commission': commission,
            'net_amount': order_amount - commission,
            'bonus_eligible': agent_stats['success_rate'] > 0.9
        }
    
    def record_transaction(self, transaction_type: str, amount: float, 
                          description: str, agent_id: str = None, 
                          related_order_id: str = None) -> str:
        """تسجيل عملية مالية"""
        conn = sqlite3.connect(self.memory_system.memory_db)
        cursor = conn.cursor()
        
        record_id = f"trans_{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        commission = 0
        
        if agent_id:
            commission_data = self.calculate_commission(amount, agent_id)
            commission = commission_data['commission']
        
        cursor.execute('''
            INSERT INTO financial_records 
            (record_id, transaction_type, amount, description, agent_id, 
             related_order_id, commission)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (record_id, transaction_type, amount, description, agent_id, 
              related_order_id, commission))
        
        conn.commit()
        conn.close()
        
        return record_id
    
    def generate_commission_report(self, agent_id: str = None, 
                                   start_date: datetime = None, 
                                   end_date: datetime = None) -> Dict:
        """إنشاء تقرير عمولات"""
        conn = sqlite3.connect(self.memory_system.memory_db)
        cursor = conn.cursor()
        
        if not start_date:
            start_date = datetime.now() - timedelta(days=30)
        if not end_date:
            end_date = datetime.now()
        
        if agent_id:
            cursor.execute('''
                SELECT SUM(amount) as total_sales, SUM(commission) as total_commission
                FROM financial_records
                WHERE agent_id = ? AND created_at BETWEEN ? AND ?
            ''', (agent_id, start_date, end_date))
        else:
            cursor.execute('''
                SELECT SUM(amount) as total_sales, SUM(commission) as total_commission
                FROM financial_records
                WHERE created_at BETWEEN ? AND ?
            ''', (start_date, end_date))
        
        result = cursor.fetchone()
        conn.close()
        
        return {
            'period': f'{start_date.date()} to {end_date.date()}',
            'total_sales': result[0] or 0,
            'total_commission': result[1] or 0,
            'net_revenue': (result[0] or 0) - (result[1] or 0),
            'agent_id': agent_id
        }
    
    def _get_agent_stats(self, agent_id: str) -> Dict:
        """جلب إحصائيات المندوب"""
        # سيتم الربط مع قاعدة البيانات الرئيسية
        return {
            'total_orders': 100,
            'successful_orders': 95,
            'success_rate': 0.95,
            'average_order_value': 500
        }


class ErrorCorrectionEngine:
    """محرك تصحيح الأخطاء الذكي"""
    
    def __init__(self):
        self.memory_system = AIMemorySystem()
    
    def detect_and_fix_error(self, error_context: str) -> Dict:
        """كشف الأخطاء وتصحيحها تلقائياً"""
        
        # تحليل نوع الخطأ
        error_type = self._identify_error_type(error_context)
        
        # جلب إجراء التصحيح المناسب
        correction = self._get_correction_action(error_type)
        
        return {
            'error_type': error_type,
            'correction': correction,
            'auto_applied': correction.get('auto_fix', False),
            'severity': correction.get('severity', 'low')
        }
    
    def _identify_error_type(self, error_context: str) -> str:
        """تحديد نوع الخطأ"""
        context_lower = error_context.lower()
        
        if 'تصنيف' in context_lower or 'فئة' in context_lower:
            return 'classification_error'
        elif 'حساب' in context_lower or 'رقم' in context_lower:
            return 'calculation_error'
        elif 'اتصال' in context_lower or 'connection' in context_lower:
            return 'connection_error'
        elif 'ديكود' in context_lower or 'encoding' in context_lower:
            return 'encoding_error'
        else:
            return 'unknown_error'
    
    def _get_correction_action(self, error_type: str) -> Dict:
        """جلب إجراء التصحيح"""
        corrections = {
            'classification_error': {
                'action': 'reclassify',
                'severity': 'medium',
                'auto_fix': True
            },
            'calculation_error': {
                'action': 'recalculate',
                'severity': 'high',
                'auto_fix': True
            },
            'connection_error': {
                'action': 'retry',
                'severity': 'medium',
                'auto_fix': False
            },
            'encoding_error': {
                'action': 'recode',
                'severity': 'low',
                'auto_fix': True
            }
        }
        
        return corrections.get(error_type, {'action': 'manual_review', 'severity': 'high'})
